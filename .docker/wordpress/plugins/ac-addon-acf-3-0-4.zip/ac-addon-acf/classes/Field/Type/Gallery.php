<?php

namespace ACA\ACF\Field\Type;

use ACA\ACF\Field;

class Gallery extends Field {

}
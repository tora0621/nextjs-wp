<?php

namespace ACA\ACF\FieldGroup;

interface Query {

	public function get_groups();

}
<?php

namespace ACP\Filtering\Model\CustomField;

use ACP\Filtering\Model;

class Media extends Model\CustomField\Image {

	// @see Model_CustomField_Image

}